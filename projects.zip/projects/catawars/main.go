package main

import "fmt"

func main() {
	a := make([]int, 0, 5)
	fmt.Println(a)
	a = add(a)
	fmt.Println(a, len(a), cap(a))

}

func add(s []int) []int {
	s = append(s, 1, 2, 3, 4, 5, 6)
	return s
}
