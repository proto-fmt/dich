package main

import (
	_ "embed"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

var (
	//go:embed test.txt
	input string
)

func main() {
	lines := strings.Split(input, "\n")
	fmt.Println("part 1:", part1(lines))
	fmt.Println("part 2:", part1(part2(lines)))
}

func part1(lines []string) int {

	digitsRegExp := regexp.MustCompile(`[1-9]`)
	var sum int

	for _, line := range lines {
		digits := digitsRegExp.FindAllString(line, -1)
		// if no numbers in the line
		if digits == nil {
			continue
		}
		res, _ := strconv.Atoi(digits[0] + digits[len(digits)-1])
		sum += res
	}

	return sum
}

func part2(lines []string) []string {
	// we need replace words on digits, and pass result in function part1()
	r := strings.NewReplacer(
		"nine", "9",
		"eight", "8",
		"seven", "7",
		"six", "6",
		"five", "5",
		"four", "4",
		"three", "3",
		"two", "2",
		"one", "1",
	)
	for i, line := range lines {
		lines[i] = r.Replace(line)
	}

	return lines
}
