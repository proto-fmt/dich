package main

import (
	_ "embed"
	"fmt"
	"log"
	"math"
	"strconv"
	"strings"
)

//go:embed input.txt
var input string

type card struct {
	id   int
	win  []int
	lose []int
}

func main() {
	cards := parseInput(input)
	var sum int
	for _, v := range cards {
		num := intersection(v.win, v.lose)
		sum += cardValue(len(num))
	}
	fmt.Println(sum)
}

func cardValue(matchCount int) int {
	if matchCount == 0 {
		return 0
	}
	value := math.Pow(2, float64(matchCount)-1)
	return int(value)
}

func parseInput(input string) (cards []card) {
	lines := strings.Split(input, "\n")

	for _, line := range lines {
		cardID, numbers, _ := strings.Cut(line, ": ")
		id, err := strconv.Atoi(strings.Fields(cardID)[1])
		if err != nil {
			log.Fatal("id parse error")
		}

		win, lose, _ := strings.Cut(numbers, " | ")

		winN := strings.Fields(win)
		loseN := strings.Fields(lose)

		winTemp := make([]int, 0, len(winN))
		loseTemp := make([]int, 0, len(loseN))
		for _, v := range winN {
			n, _ := strconv.Atoi(v)
			winTemp = append(winTemp, n)
		}
		for _, v := range loseN {
			n, _ := strconv.Atoi(v)
			loseTemp = append(loseTemp, n)
		}

		card := card{
			id:   id,
			win:  winTemp,
			lose: loseTemp,
		}
		cards = append(cards, card)
	}

	return

}

func intersection(arr1, arr2 []int) []int {
	result := []int{}
	uniqueValues := make(map[int]bool)

	for _, num := range arr1 {
		uniqueValues[num] = true
	}

	for _, num := range arr2 {
		if uniqueValues[num] {
			result = append(result, num)
		}
	}

	return result
}
