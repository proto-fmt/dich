package main

import (
	_ "embed"
	"fmt"
	"strings"
)

//go:embed test.txt
var input string

func main() {
	parseInput(input)
}

func parseInput(input string) {
	lines := strings.Split(input, "\n")
	AppendLines(&lines)

	var allDigits []int
	for _, line := range lines {
		var current []rune
		for _, y := range line {
			if y <= '9' && y >= '0' {
				current = append(current, y)
			} else {
				allDigits = append(allDigits, int(current[y]))
			}
		}
	}
	fmt.Println(allDigits)

}

//fmt.Printf("%q\n", lines)

func AppendLines(lines *[]string) {
	line := strings.Repeat(".", len((*lines)[0])) // len as all lines

	*lines = append([]string{line}, *lines...) // top
	*lines = append(*lines, line)              // bottom
}
