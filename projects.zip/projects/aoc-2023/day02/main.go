package main

import (
	_ "embed"
	"fmt"
	"log"
	"strconv"
	"strings"
)

type game struct {
	id     int
	rounds []round
}
type round struct {
	red   int
	green int
	blue  int
}

//go:embed input.txt
var input string

func main() {
	games := parseInput(input) // slice of all games

	var sumPart1, sumPart2, r, g, b int
	for _, v := range games {
		if part1(v, 12, 13, 14) {
			sumPart1 += v.id
		}

		r, g, b = part2(v)
		sumPart2 += r * g * b

	}

	fmt.Println("Part 1:", sumPart1)
	fmt.Println("Part 2:", sumPart2)
}

func getGameID(str string) int {
	id, err := strconv.Atoi(strings.Fields(str)[1])
	if err != nil {
		log.Fatal("Atoi numGame: bad number")
	}
	return id
}

// part 1
func part1(game game, r, g, b int) bool {
	for _, v := range game.rounds {
		if v.red > r || v.green > g || v.blue > b {
			return false
		}

	}

	return true
}

// part 2
func part2(game game) (r, g, b int) {
	for _, v := range game.rounds {
		if v.red > r {
			r = v.red
		}
		if v.green > g {
			g = v.green
		}
		if v.blue > b {
			b = v.blue
		}
	}
	return
}

func parseInput(input string) (games []game) {

	lines := strings.Split(input, "\n")

	for _, line := range lines {
		var game game

		num, data, _ := strings.Cut(line, ": ")
		game.id = getGameID(num) // id game

		for _, r := range strings.Split(data, "; ") {
			var round round

			for _, v := range strings.Split(r, ", ") {

				hand := strings.Fields(v) // hand[0] - number, hand[1] - color

				num, err := strconv.Atoi(hand[0])
				if err != nil {
					log.Fatal("Atoi hand: bad number")
				}
				color := hand[1]

				switch color {
				case "red":
					round.red = num
				case "green":
					round.green = num
				case "blue":
					round.blue = num
				}

			}
			game.rounds = append(game.rounds, round)
		}
		games = append(games, game)
	}
	return
}
