package proxy

import "strings"

// Sanitize takes a proxy string as input and returns a sanitized version of it.
func Sanitize(proxy string) string {
	//  A single IPv6 address can be text represented in many ways.
	// `strings.ToLower` is used because 2001:db8::68:100 (lowercase) is the same as 2001:DB8::68:100 (uppercase).
	// This is a minimal reduction to at least some unified presentation format.
	return strings.ToLower(strings.TrimSpace(proxy))
}
