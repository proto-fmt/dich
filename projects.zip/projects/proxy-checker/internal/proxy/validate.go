package proxy

import (
	"net"
	"strconv"
	"strings"
)

// IsValid checks if the given proxy string is valid.
// A valid proxy string should be in the format "ip:port", where:
// - IP can be IPv4 (example "192.0.2.1") or IPv6 (example "2001:db8::68")
// - Port can be an integer between 1 and 65535 (inclusive).
func IsValid(proxy string) bool {
	lastIndex := strings.LastIndex(proxy, ":")
	if lastIndex == -1 {
		return false
	}

	// Validate the IP address
	ip := net.ParseIP(proxy[:lastIndex])
	if ip == nil || ip.IsLoopback() || ip.IsPrivate() || ip.IsUnspecified() {
		return false
	}

	// Validate the port number
	port, err := strconv.Atoi(proxy[lastIndex+1:])
	if err != nil || port < 1 || port > 65535 {
		return false
	}

	return true
}

// func RemoveDuplicates(proxies []string) ([]string, int) {
// 	// return the clean slice and the number of deletions
// 	temp := make(map[string]bool)
// 	res := make([]string, 0, len(proxies))
// 	for _, v := range proxies {
// 		if _, ok := temp[v]; !ok {
// 			temp[v] = true
// 			res = append(res, v)
// 		}
// 	}

// 	// remove unused capacity `res`
// 	if cap(res) < cap(proxies) {
// 		res = res[:len(res):len(res)]
// 	}
// 	return res, len(proxies) - len(res)

// }
