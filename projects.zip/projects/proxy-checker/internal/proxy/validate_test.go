package proxy

import (
	"fmt"
	"testing"
)

func TestValidate(t *testing.T) {
	tests := []struct {
		proxy    string
		expected bool
	}{
		{"192.168.1.1:8080", false},                               // invalid IPv4 (private IP)
		{"10.255.255.255:80", false},                              // invalid IPv4 (private IP)
		{"192.168.1.1:8080  ", false},                             // invalid IPv4 (spaces)
		{"192. 168.1.1:8080  ", false},                            // invalid IPv4 (space between octets)
		{"invalidIP:8080", false},                                 // invalid IP
		{"192.168.1.1:99999", false},                              // invalid port
		{"invalidformat", false},                                  // invalid format
		{"256.256.256.256:8080", false},                           // invalid IPv4
		{"2001:0db8:85a3:0000:0000:8a2e:0370:7334:8080", true},    // valid IPv6 and port
		{"2001:0gb8:85a3:0000:0000:8z2e:0370:7334:8080", false},   // invalid IPv6 (invalid hex)
		{"  2001:0gb8:85a3:0000:0000:8z2e:0370:7334:8080", false}, // invalid IPv6 (spaces)
		{"2001:db8::68", false},                                   // valid IPv6, but empty port
		{"2001:db8: :68", false},                                  // invalid IPv6 (space between octets)
		{"2001:db8::68:100", true},                                // valid IPv6 and port
		{"2001:DB8::68:100", true},                                // valid IPv6(capital letters) and port
		{"192.168.1.1:-80", false},                                // invalid port
		{"192.168.1.1:0", false},                                  // invalid port
		{"127.0.0.0:90", false},                                   // loopback IPv4
		{"::1:90", false},                                         // loopback IPv6
		{"0.0.0.0:123", false},                                    // unspecified IPv4
		{":::90", false},                                          // unspecified IPv6
		{"   ", false},
		{"", false},
		{"\n\t", false},
	}

	for i, test := range tests {
		testName := fmt.Sprintf("[Test-#%d]", i)
		t.Run(testName, func(t *testing.T) {
			if res := IsValid(test.proxy); res != test.expected {
				t.Errorf("Got '%t', want '%t' for '%s'", res, test.expected, test.proxy)
			}
		})
	}
}

// func TestRemoveDuplicates(t *testing.T) {
// 	type test struct {
// 		got, want []string
// 		count     int
// 	}
// 	tests := []test{
// 		{
// 			[]string{"111", "222", "1", "", "111", "", "3", "4", "15", "", "15", " ", "123", " ", "1"},
// 			[]string{"111", "222", "1", "", "3", "4", "15", " ", "123"},
// 			6,
// 		},
// 		{
// 			[]string{"123", "123"},
// 			[]string{"123"},
// 			1,
// 		},
// 		{
// 			[]string{"1", "1", "1", "1"},
// 			[]string{"1"},
// 			3,
// 		},
// 	}

// 	for i, tt := range tests {
// 		testName := fmt.Sprintf("[Test-#%d]", i)
// 		t.Run(testName, func(t *testing.T) {
// 			got, i := RemoveDuplicates(tt.got)
// 			if !assert.ElementsMatch(t, got, tt.want) {
// 				t.Errorf("got %v, want %v", got, tt.want)
// 			}
// 			if i != tt.count {
// 				t.Errorf("got %d, want %d", i, tt.count)
// 			}
// 		})
// 	}
// }

func TestIsValid(t *testing.T) {
	type args struct {
		proxy string
	}
	tests := []struct {
		name string
		args args
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := IsValid(tt.args.proxy); got != tt.want {
				t.Errorf("IsValid() = %v, want %v", got, tt.want)
			}
		})
	}
}
