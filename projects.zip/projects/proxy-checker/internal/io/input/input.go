package input

import (
	"bufio"
	"os"

	"github.com/proto-fmt/proxy-checker/internal/proxy"
)

type Statistic struct {
	All       uint // All is the number of all input proxies
	Invalid   uint // Invalid is the number of removed proxies after validation
	Duplicate uint // Duplicate is the number of removed duplicate proxies
}

var stat = &Statistic{}

/*
Parse parses the input file and returns a slice of cleaned and valid proxies.
It removes:

- proxies not in the format "ip:port"

- incorrect IPv4/IPv6/port

- duplicate proxies

- leading and trailing white space
*/
func Parse(filePath string) (proxies []string, stat Statistic, err error) {

	file, err := os.Open(filePath)
	if err != nil {
		return nil, stat, err
	}
	defer file.Close()

	// Calculate the capacity of the proxies slice based on the file size
	// 15 bytes is the average length of one line in a file with a proxies
	if fileStat, err := file.Stat(); err == nil {
		proxies = make([]string, 0, fileStat.Size()/15)
	}

	// Map to store unique proxies
	uniq := make(map[string]struct{}, len(proxies))

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		curProxy := proxy.Sanitize(scanner.Text())
		if curProxy == "" {
			continue
		}

		stat.All++

		// Check for invalid proxy
		if !proxy.IsValid(curProxy) {
			stat.Invalid++
			continue
		}

		// Check for duplicate proxy
		if _, ok := uniq[curProxy]; !ok {
			uniq[curProxy] = struct{}{}
		} else {
			stat.Duplicate++
		}

		proxies = append(proxies, curProxy)
	}
	if err = scanner.Err(); err != nil {
		return nil, stat, err
	}

	// Truncate the slice to the actual length if the capacity is greater than the lengths
	if cap(proxies) > len(proxies) {
		proxies = proxies[:len(proxies):len(proxies)]
	}

	return proxies, stat, nil
}

func ParseInput(files []string) (proxies []string, err error) {

	for _, v := range files {
		file, err := parseFile(v)
		if err != nil {
			return nil, err
		}
		proxies = append(proxies, file...)

	}

	// Truncate the slice to the actual length if the capacity is greater than the lengths
	if cap(proxies) > len(proxies) {
		proxies = proxies[:len(proxies):len(proxies)]
	}

	return proxies, nil
}

// parseFile parses a file and returns a slice of proxies and an error.
// The function returns a slice of strings, which represents the proxies
// extracted from the file, and an error if any occurred during the parsing
// process.
func parseFile(filePath string) (proxies []string, err error) {

	file, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	// Calculate the capacity of the proxies slice based on the file size.
	// 15 bytes is the average length of one line in a file with a proxies.
	if fileStat, err := file.Stat(); err == nil {
		proxies = make([]string, 0, fileStat.Size()/15)
	}

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		curProxy := proxy.Sanitize(scanner.Text())
		if curProxy == "" {
			continue
		}

		stat.All++

		if !proxy.IsValid(curProxy) {
			stat.Invalid++
			continue
		}

		proxies = append(proxies, curProxy)
	}
	if err = scanner.Err(); err != nil {
		return nil, err
	}

	return proxies, nil
}
