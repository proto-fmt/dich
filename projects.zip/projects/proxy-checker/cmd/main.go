package main

import (
	"flag"
	"fmt"

	"os"

	"github.com/proto-fmt/proxy-checker/config"
	"github.com/proto-fmt/proxy-checker/pkg/logger"
)

var log = struct {
	err  *logger.Logger
	info *logger.Logger
}{
	err:  logger.New("[ ERROR ]", os.Stderr, true),
	info: logger.New("[ OK ]", os.Stdout, false),
}

func main() {

	options, err := config.ParseFlags()
	if err != nil {
		if err == flag.ErrHelp {
			return
		}
		log.err.Println(err.Error())
		return
	}

	log.info.Println("Parse options")
	fmt.Println(*options)

}

// 	fmt.Print("Parse input file... ")
// 	proxies, statistic, err := input.Parse("testdata/test.txt")
// 	if err != nil {
// 		fmt.Println("FATAL!", err)
// 	} else {
// 		fmt.Println("OK!")
// 		fmt.Printf("  [%d] Load total proxies\n", statistic.All)
// 		fmt.Printf("  [%d] Delete duplicates proxies\n", statistic.Duplicate)
// 		fmt.Printf("  [%d] Delete invalid proxies\n", statistic.Invalid)
// 		fmt.Printf("  [%d] Total proxies for check\n", statistic.All-statistic.Duplicate-statistic.Invalid)
// 	}

// 	var wg sync.WaitGroup

// 	for i, proxy := range proxies {
// 		wg.Add(1)
// 		go func(proxy string, i int) {
// 			defer wg.Done()
// 			if checkProxy("socks4://"+proxy, "https://www.google.com/", 30) {
// 				fmt.Printf("%d Proxy %s GOOD\n", i, proxy)

// 			} else {
// 				//fmt.Printf("%d Proxy %s BAD\n", i, proxy)
// 				{

// 				}
// 				{
// 				}
// 				{
// 				}

// 			}

// 		}(proxy, i)
// 	}
// 	wg.Wait()
// 	//elapsed := time.Since(start)
// 	//fmt.Println(elapsed)
// }

// func checkProxy(proxy, target string, timeout int64) bool {
// 	ctx, cancel := context.WithTimeout(context.Background(), time.Second*time.Duration(timeout))
// 	defer cancel()

// 	proxyURL, err := url.Parse(proxy)
// 	if err != nil {
// 		fmt.Println("Proxy parse error")
// 		return false
// 	}

// 	client := &http.Client{
// 		Transport: &http.Transport{
// 			Proxy: http.ProxyURL(proxyURL),
// 		},
// 	}

// 	req, err := http.NewRequestWithContext(ctx, "GET", target, nil)
// 	if err != nil {
// 		fmt.Println("Request with context error")
// 		return false
// 	}
// 	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36")
// 	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
// 	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
// 	req.Header.Set("Accept-Encoding", "gzip, deflate")
// 	req.Header.Set("Connection", "keep-alive")
// 	req.Header.Set("Upgrade-Insecure-Requests", "1")

// 	resp, err := client.Do(req)
// 	if resp != nil {
// 		defer resp.Body.Close()
// 	}
// 	if err != nil || resp.StatusCode != http.StatusOK {
// 		return false
// 	}

// 	return true

// }
