package color

import (
	"fmt"
	"runtime"
)

var (
	reset  = "\033[0m"
	red    = "\033[31m"
	green  = "\033[32m"
	yellow = "\033[33m"
	cyan   = "\033[36m"
)

func init() {
	if runtime.GOOS == "windows" {
		reset = ""
		red = ""
		green = ""
		yellow = ""
	}
}

func colorizeString(str string, color string) string {
	return fmt.Sprintf("%s%s%s", color, str, reset)
}

// Red returns a string that is colorized in red.
func Red(str string) string {
	return colorizeString(str, red)
}

// Red returns a string that is colorized in green.
func Green(str string) string {
	return colorizeString(str, green)
}

// Red returns a string that is colorized in yellow.
func Yellow(str string) string {
	return colorizeString(str, yellow)
}

// Cyan returns a string that is colorized in cyan.
func Cyan(str string) string {
	return colorizeString(str, cyan)
}
