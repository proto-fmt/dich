package logger

import (
	"fmt"
	"io"
	"os"
	"strings"
	"time"

	"github.com/proto-fmt/proxy-checker/pkg/color"
)

type Logger struct {
	Prefix string
	Out    io.Writer
	Time   bool
}

func New(prefix string, out io.Writer, time bool) *Logger {
	return &Logger{
		Prefix: prefix,
		Out:    out,
		Time:   time,
	}
}

func (l *Logger) Println(str string) {

	var b strings.Builder

	switch l.Out {
	case os.Stdout:
		l.Prefix = color.Green(l.Prefix)
	case os.Stderr:
		l.Prefix = color.Red(l.Prefix)
	}

	b.WriteString(l.Prefix)
	if l.Time {
		b.WriteString(fmt.Sprintf("[%s] -", color.Cyan(time.Now().Format("15:04:05"))))
	}
	b.WriteString(fmt.Sprintf(" %s", str))
	b.WriteString("\n")

	fmt.Fprint(l.Out, b.String())
}
