package config

import (
	"bytes"
	"errors"
	"flag"
	"os"
	"strconv"
	"strings"
	"text/tabwriter"
)

type Flags struct {
	Input    []string
	Output   string
	Protocol string
	Type     string
	Timeout  int
	Threads  int
}

// ParseFlags initializes the flags app, also processes and displays flag parse errors or help information.
//
// Returns a struct containing all flags and an error.
//
// A not nil error indicates that the application cannot continue running,or err == flag.ErrHelp so the struct flags will return nil.
func ParseFlags() (*Flags, error) {

	// buffer and flagSet are used to separate flag parsing error and help information.
	// more : https://www.reddit.com/r/golang/comments/3huv89/ask_rgolang_a_way_to_prevent_flag_from_printing/
	flagSet := flag.NewFlagSet("", flag.ContinueOnError)

	// set flags to default values, ​​because uses `flagSet.Func()`.
	// feature `flagSet.Func()` - if a flag is not provided, the corresponding `flagSet.Func()` function will not be called,
	// this means that cannot set a default value inside a `flagSet.Func()` function.
	flags := &Flags{
		Input:    []string{"input.txt"},
		Output:   "output.txt",
		Protocol: "https",
		Type:     "",
		Timeout:  10,
		Threads:  100,
	}

	flagSet.Func("input", "path to the file(s), separated by commas, containing the proxy to check (default: \"input.txt\")", func(val string) error {
		files := strings.Split(val, ",")
		for _, file := range files {
			if strings.TrimSpace(file) == "" {
				return errors.New("invalid path")
			}
		}
		flags.Input = files
		return nil
	})

	flagSet.Func("output", "file that will contain checked proxies(will be created if it does not exist)", func(val string) error {
		if strings.TrimSpace(val) == "" {
			return errors.New("invalid path")
		}
		flags.Output = val
		return nil
	})

	flagSet.Func("protocol", "Protocol proxy: \"http\", \"https\", \"socks4\", \"socks5\"", func(val string) error {
		for _, allowed := range []string{"http", "https", "socks4", "socks5"} {
			if val == allowed {
				flags.Protocol = val
				return nil
			}
		}
		return errors.New("must be one of \"http\", \"https\", \"socks4\", \"socks5\"")
	})

	flagSet.Func("type", "Type proxy: \"\", \"elite\", \"anonymous\", \"transparent\"", func(val string) error {
		for _, allowed := range []string{"", "elite", "anonymous", "transparent"} {
			if val == allowed {
				flags.Type = val
				return nil
			}
		}
		return errors.New("must be one of \"\", \"elite\", \"anonymous\", \"transparent\"")
	})

	flagSet.Func("timeout", "Timeout flag description", func(val string) error {
		if val == "" {
			return errors.New("invalid timeout")
		}
		timeOut, err := strconv.Atoi(val)
		if err != nil {
			return errors.New("only integer number")
		}
		if timeOut < 0 {
			return errors.New("must be positive")
		}
		flags.Timeout = timeOut
		return nil
	})

	flagSet.Func("threads", "Threads flag description", func(val string) error {
		if val == "" {
			return errors.New("invalid threads")
		}
		threads, err := strconv.Atoi(val)
		if err != nil {
			return errors.New("only integer number")
		}
		if threads < 0 {
			return errors.New("must be positive")
		}
		flags.Threads = threads
		return nil
	})

	// create a buffer to capture the flags usage information
	usage := &bytes.Buffer{}
	flagSet.SetOutput(usage)

	err := flagSet.Parse(os.Args[1:])

	usage.Reset()

	if err != nil {

		// check if the error is a help flag error ("-help", "--help", "-h", "--h")
		if err == flag.ErrHelp {
			help(usage, flagSet)
			return nil, err

		} else {
			// if this is parse error
			return nil, errors.New(err.Error())
		}
	}

	return flags, nil
}

func help(usage *bytes.Buffer, flagSet *flag.FlagSet) {
	// create a tab writer to format the output
	w := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', tabwriter.Debug)

	usage.WriteString(">>> PROXY-CHECKER <<<\n")
	usage.WriteString("Usage: proxy-checker [OPTIONS]...\n\n")
	usage.WriteString("Options:\n")

	flagSet.VisitAll(func(f *flag.Flag) {
		usage.WriteString("\t-" + f.Name + "\t" + f.Usage + "\n")
	})

	usage.WriteString("\nExamples:\n")
	usage.WriteString("\tproxy-checker -input=input.txt -output=\"output.txt\"\n")
	usage.WriteString("\tproxy-checker -input proxy.txt -protocol=https -threads 1000\n")
	usage.WriteString("\tproxy-checker -input list.txt\n")

	usage.WriteTo(w)
	w.Flush()

}
