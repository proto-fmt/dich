package config

const (
	version = "v.1.0.0"
	name    = "PROXY-CHECKER"
)
