package main

import (
	"flag"
	"fmt"
)

func main() {
	flag.String("p", "80", "One or a range of ports.\nExample:\n-p 80-443\n-p 31\n")
	flag.Parse()

	fmt.Println(flag.Arg(0))
}
