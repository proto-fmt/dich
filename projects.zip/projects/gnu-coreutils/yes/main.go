package main

import "os"

const bufSize = 16 * 1024

func main() {

	var text []byte
	buffer := make([]byte, bufSize)

	if len(os.Args) > 1 {
		text = []byte(os.Args[1] + "\n")
	} else {
		text = []byte("y\n")
	}

	used := 0
	for used+len(text) < bufSize {
		copy(buffer[used:], text)
		used += len(text)
	}

	// cut off unused bytes
	buffer = buffer[:used]

	for {
		os.Stdout.Write(buffer)
	}

}
