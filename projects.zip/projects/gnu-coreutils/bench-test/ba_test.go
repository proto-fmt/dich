package benching

import (
	"fmt"
	"testing"
)

func BenchmarkSimplest(b *testing.B) {
	s := []byte("hello")
	lens := len(s)

	for i := 0; i < b.N; i++ {
		fmt.Println(lens)
	}

}
