package main

import (
	"fmt"
	"time"
)

func main() {

	// Length is 3.
	string1 := []byte("cat")
	// Length is 13 times 5 which is 65.
	string2 := []byte("cat0123456789" +
		"cat0123456789" +
		"cat0123456789" +
		"cat0123456789" +
		"cat0123456789")

	t0 := time.Now()

	// Version 1: length of short string.
	for i := 0; i < 10000000; i++ {
		result := len(string1)
		if result != 3 {
			return
		}
	}

	t1 := time.Now()

	// Version 2: length of long string.
	for i := 0; i < 10000000; i++ {
		result := len(string2)
		if result != 65 {
			return
		}
	}

	t2 := time.Now()
	// Print results.
	fmt.Println(t1.Sub(t0))
	fmt.Println(t2.Sub(t1))
}
