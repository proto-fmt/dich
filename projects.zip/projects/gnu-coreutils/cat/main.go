package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
)

var numLines *bool

func read(r io.Reader) {
	rd := bufio.NewReader(r)
	numLine := 1

	for {
		line, _, err := rd.ReadLine()
		if err == io.EOF {
			break
		}

		if *numLines {
			fmt.Printf("%d  %s\n", numLine, line)
			numLine++
		} else {
			fmt.Printf("%s\n", line)
		}
	}

}

func init() {
	numLines = flag.Bool("n", false, "Number output lines, starting at 1.")
	flag.Parse()
}

func main() {

	if len(flag.Args()) == 0 {
		read(os.Stdin)
	}

	for _, v := range flag.Args() {
		file, err := os.Open(v)
		if err != nil {
			log.Fatalf("Error when opening file: %s", err)
		}
		defer file.Close()

		read(file)
	}

}
