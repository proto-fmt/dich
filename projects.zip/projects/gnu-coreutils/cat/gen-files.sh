#!/usr/bin/env bash

# Generate files for tests.
# In generated files ALWAYS 1 char = 1 bytes

SUCCES="\033[1m\033[42m OK \033[0m"
FAILED="\033[1m\033[41m FAIL \033[0m"

# Func `bigLine()` to create a file with one large non-breaking line.
bigLine() {

	let sizeLine=1024*1024*10		# number of chars per line
	path="test/big-one-line/"		# path to save files generated this function

	if ! [ -d $path ]; then
		mkdir $path
		echo -e "${SUCCES} --> Create directory $path"
	fi
	
	tr -dc "[:alpha:]" < /dev/urandom | head -c $sizeLine > ${path}${sizeLine}Bytes
	echo -e "${SUCCES} --> Create file ${path}${sizeLine}Bytes"

}
bigLine


# Func `manyLines()` to create a file with a certain number of lines.
manyLines(){

	let sizeLine=1*100 		# number of chars per line
	let countLines=1*2000 	# number of lines in created file
	path="test/many-lines/"	# path to save files generated this function

	if ! [ -d $path ]; then
		mkdir $path
		echo -e "${SUCCES} --> Create directory $path"
	fi

	tr -dc "[:alpha:]" < /dev/urandom | fold -w $sizeLine | head -n $countLines > ${path}${sizeLine}Bytes-${countLines}Lines
	echo -e "${SUCCES} --> Create file ${path}${sizeLine}Bytes-${countLines}Lines"
}
manyLines
