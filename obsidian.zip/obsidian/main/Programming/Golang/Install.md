Скачиваем нужный тарболл(.tar) с офицальной страницы https://go.dev/dl/
$ wget https://go.dev/dl/go1.20.3.linux-amd64.tar.gz



Проверяем хэш-сумму тарболла, с контрольной суммой на странице скачивания:
$ sha256sum go1.20.3.linux-amd64.tar.gz
979694c2c25c735755bf26f4f45e19e64e4811d661dd07b8c010f7a8e18adfca  go1.20.3.linux-amd64.tar.gz



Если есть прошлые установки Go, то их нужно удалить. 
Запустить команду от root или sudo:
$ sudo rm -rf /usr/local/go



Извлеките файлы из тарболла в каталог /usr/local
$ tar -C /usr/local -xzf go1.20.3.linux-amd64.tar.gz


Добавьте /usr/local/go/bin в переменную окружения PATH. Я делаю это через редактирование /etc/environment дописывая в конец перед закрывающей скобкой :/usr/local/go/bin. Для редактирования требуются права root или использование sudo. В результате получается:
$ echo $PATH
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/usr/local/go/bin
И применяем изменения:
$ source /etc/environment  




Проверяем:
$ go version
go version go1.20.3 linux/amd64


Дописать установка нескольких версий 
Дописать удаление go

