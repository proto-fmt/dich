
### Получить заголовки запроса 
Используй опцию `--versbose` или `-v`, чтобы получить значения заголовков запроса и заголовков ответа. 
```bash
# получить не только заголовки ответа, но и запроса
curl -v <url> # -v, --verbose

# --head запрос с методом HEAD
curl --head <url> 

# -X, --request задает метод запроса
curl -X GET <url>


# -H, --header указание/добавить заголовок
curl -H "Content-Type: application/json" <url>


# -A, --user-agent изменить user-agent
curl -A "my_user_agent" <url> 

# -I какие заголовки отдает сервер
curl -I <url>
```



