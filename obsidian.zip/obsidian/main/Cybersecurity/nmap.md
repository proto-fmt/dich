#nmap

Nmap(Network Mapper)

When no host discovery options are provided, Nmap follows the following approaches to discover live hosts:
- When a _privileged_ user tries to scan targets on a local network (Ethernet), Nmap uses _ARP requests_. A privileged user is `root` or a user who belongs to `sudoers` and can run `sudo`.
- When a _privileged_ user tries to scan targets outside the local network, Nmap uses ICMP echo requests, TCP ACK (Acknowledge) to port 80, TCP SYN (Synchronize) to port 443, and ICMP timestamp request.
- When an _unprivileged_ user tries to scan targets outside the local network, Nmap resorts to a TCP 3-way handshake by sending SYN packets to ports 80 and 443.

`nmap -sL TARGETS`  - дает лист целей, без их сканирования, `-n` не будет запрашиваться DNS

`-sn`  - disable port scan. If you want to use Nmap to discover online hosts without port-scanning the live systems

`-PR` - ARP requests 
`nmap -PR -sn TARGETS` - where `-PR` indicates that you only want an ARP scan, `-sn` without port-scanning

`-PE` - ICMP requests (ICMP Type 8/Echo)
Because ICMP echo requests tend to be blocked, you might also consider ICMP Timestamp or ICMP Address Mask requests to tell if a system is online.

`-PP` - ICMP timestamp requests (ICMP Type 13)

`-PM` - ICMP Address Mask (ICMP Type 17)


`-PS` - TCP SYN ping. 
If you want Nmap to use TCP SYN ping, you can do so via the option `-PS` followed by the port number, range, list, or a combination of them. `-PS21` , `-PS21-25` , `-PS80,443,8080`. Privileged users (root and sudoers) can send TCP SYN packets and don’t need to complete the TCP 3-way handshake even if the port is open. Unprivileged users have no choice but to complete the 3-way handshake if the port is open.

`-PA` - TCP ACK ping. 
Only Privileged users (root and sudoers). If you try it as an unprivileged user, Nmap will attempt a 3-way handshake. `-PA21`, `-PA21-25` , `-PA80,443,8080` . The target responds with the RST flag set because the TCP packet with the ACK flag is not part of any ongoing connection. The expected response is used to detect if the target host is up.


`-PU` - UDP ping.
Contrary to TCP SYN ping, sending a UDP packet to an open port is not expected to lead to any reply. However, if we send a UDP packet to a closed UDP port, we expect to get an ICMP port unreachable packet(ICMP Type 3); this indicates that the target system is up and available.


`-sT` - TCP Connect Scans. **Full 3-way handshake**
_RST_ if port closed. 
_SYN/ACK_ if port open.
Nmap sends a TCP SYN request, and receives nothing back. This indicates that the port is being protected by a firewall and thus the port is considered to be _filtered_. Однако, можно насторить firewall и на ответ _RST_. This can make it extremely difficult (if not impossible) to get an accurate reading of the target(s).


`-sS` - SYN "Half-open" or Stealth Scans. **NOT Full 3-way handshake**
SYN scans are the default scans used by Nmap _if run with sudo permissions_. If run **without** sudo permissions, Nmap defaults to the TCP Connect scan


`-sU` - UDP Scans.
If a UDP port doesn't respond to an Nmap scan,  it be marked as  `open | filtered`
When a packet is sent to a _closed_ UDP port, the target should respond with an ICMP (ping) packet containing a message that the port is unreachable. This clearly identifies closed ports, which Nmap marks as such and moves on.


`-sN` - NULL scan when the TCP request is sent with no flags set at all (no SYN, no ACK, no other). As the name suggests, NULL scans (`-sN`) are when the TCP request is sent with no flags set at all. As per the RFC, the target host should respond with a RST if the port is closed.

`-sF` - FIN scan. работаeт практически одинаково c `-sN`; однако вместо отправки совершенно пустого пакета запрос отправляется с флагом FIN (обычно используется для корректного закрытия активного соединения). Еще раз, Nmap ожидает RST, если порт закрыт.


`-sX`  - Xmas scan. As with the other two scans in this class, Xmas scans (`-sX`) send a malformed TCP packet and expects a RST response for closed ports. It's referred to as an xmas scan as the flags that it sets (PSH, URG and FIN) give it the appearance of a blinking christmas tree when viewed as a packet capture in Wireshark.


## NSE
`/usr/shate/nmap/scripts`, `/usr/share/nmap/scripts/script.db` - All of the NSE scripts are stored in this directory by default -- this is where Nmap looks for scripts when you specify them.