# Arch Linux / BIOS / GPT / GRUB 

## 1. Live media creation
Use [`lsblk`](https://wiki.archlinux.org/title/Device_file#lsblk) utility which lists yours block devices, it should be something like 'sda' or 'sdb'.  
See how to create an Arch linux installation medium [here](https://wiki.archlinux.org/title/USB_flash_installation_medium).  
> [!IMPORTANT]
> Secure boot must be disabled from the system bios menu to boot the installation medium. 

Create installation medium: 
```bash
dd bs=4M if=/<path>/<to>/<archlinux>.iso of=/dev/<sdx> status=progress && sync
```

## 2. Initial network setup
Check if the [network interface](https://wiki.archlinux.org/title/Network_configuration#Network_interfaces) is enabled with [`ip`](https://man.archlinux.org/man/ip.8.en):
```bash
ip a # all interfaces
ping 1.1.1.1 # connection verified
```  
**If uses WiFi:**  
Make sure the card isn't blocked with [`rfkill`](https://wiki.archlinux.org/title/Network_configuration/Wireless#Rfkill_caveat):
```bash
rfkill list # if the card is soft-blocked by the kernel, use this command: `rfkill unblock wifi`
```  
Authenticate to a wireless network in an [`iwd`](https://wiki.archlinux.org/title/Iwd#iwctl) interactive prompt:  
```bash
iwctl
[iwd] device list # list all wireless devices
[iwd] station <device> scan # scan for networks
[iwd] station <device> get-networks # list all available networks
[iwd] station <device> connect <SSID> # finally, to connect to a network
```

## 3. System clock
Set system clock [`timedatectl`](https://man.archlinux.org/man/timedatectl.1):  
```bash
timedatectl status # check status
timedatectl set-ntp true # if need
```


## 4. Disk partitioning
More about partitioning: [here](https://wiki.archlinux.org/title/partitioning)  
On a BIOS/GPT configuration, a [`BIOS boot`](https://wiki.archlinux.org/title/GRUB#GUID_Partition_Table_(GPT)_specific_instructions) partition is required. GRUB embeds its `core.img` into this partition.  
Create three partitions:
   1. 1M for `BIOS boot`  partition, 
   2. 4G `swap` (for [`hibernation`](https://wiki.archlinux.org/title/Power_management/Suspend_and_hibernate#Hibernation))
   3. and the rest goes to `/`

I like -> [`gdisk`](https://man.archlinux.org/man/gdisk.8), the codes below are specifically for `gdisk`.  

| Mount point on the installed system | Partition | Partition type        | Code | Size      |
| ----------------------------------- | --------- | --------------------- | ---- | --------- |
| None                                | /dev/sda1 | BIOS boot             | ef02 | 1M        |
| [ SWAP ]                            | /dev/sda2 | Linux swap            | 8200 | 4G        |
| /                                   | /dev/sda3 | Linux x86-64 root (/) | 8304 | remainder |

## 5. Format the partitions
```bash
mkfs.ext4 /dev/sda3
```

## 6. Mount partitions
[`mount`](https://wiki.archlinux.org/title/File_systems#Mount_a_file_system) root partition to `/mnt` and activate `swap partition`:  
```bash
mount /dev/sda3 /mnt
mkswap /dev/sda2 && swapon /dev/sda2 
```

## 7. Install essential packages
```bash
pacstrap /mnt base linux linux-firmware intel-ucode sudo nano micro
```

## 8. Fstab
Generate a [`fstab`](https://wiki.archlinux.org/title/Fstab) file from detected mounted block devices, defined by [`UUID`](https://wiki.archlinux.org/title/Persistent_block_device_naming#by-uuid):  
```bash
genfstab -U /mnt >> /mnt/etc/fstab
cat /mnt/etc/fstab # check the resulting
```

## 9. Change Root
[`Chroot`](https://wiki.archlinux.org/title/Chroot) into the new system: 
```bash
arch-chroot /mnt
```

## 10. Time Zone
Set the [time zone](https://wiki.archlinux.org/title/System_time#Time_zone): 
```bash
ln -sf /usr/share/zoneinfo/Asia/Yekaterinburg /etc/localtime
```  
Generate `/etc/adjtime` with [`hwclock`](https://man.archlinux.org/man/hwclock.8):  
```bash
hwclock --systohc
date # check result
```

## 11. Localization:
Edit `/etc/locale.gen` and uncomment `en_US.UTF-8 UTF-8` and `ru_RU.UTF-8 UTF-8`. After edit, generate the locales:
```bash
locale-gen
```
Create the [`/etc/locale.conf`](https://man.archlinux.org/man/locale.conf.5) file and set the [`system locale`](https://wiki.archlinux.org/title/Locale#Setting_the_system_locale):
```bash
echo LANG=en_US.UTF-8 > /etc/locale.conf
```

Создаем файл конфигурации для консоли (иначе будут кракозябры вместо русских букв):
```# nano /etc/vconsole.conf
  ________________
  KEYMAP=ru
  FONT=cyr-sun16
  ----------------
```

## 12. Network configuration:
Create  [`/etc/hostname`](https://wiki.archlinux.org/title/Network_configuration#Set_the_hostname):
```bash
echo hostname > /etc/hostname
```
Add matching entries to [`/etc/hosts`](https://man.archlinux.org/man/hosts.5):
```bash
127.0.0.1    localhost  
::1          localhost  
```

**Choose one:**
   - [`Systemd-networkd`](https://wiki.archlinux.org/title/Systemd-networkd)
   - [`NetworkManager`](https://wiki.archlinux.org/title/NetworkManager) 

### Systemd-networkd
Systemd-networkd has internal DHCP client

```bash
pacman -S wpa_supplicant

# connect to the network with wpa_passphrase:
wpa_passphrase <ssid> <password> > /etc/wpa_supplicant/wpa_supplicant-<interface>.conf

# enable and start the wpa_supplicant daemon
systemctl enable --now wpa_supplicant@<interface>

# setup systemd-networkd for wireless networking
micro /etc/systemd/network/25-wireless.network
```
```bash
[Match]
Name=<interface>

[Network] 
DHCP=yes
```

Enable and start systemd-network service daemon
```bash
systemctl enable systemd-networkd
systemctl enable systemd-resolved
```

### NetworkManager
If choose `NetworkManager`
```bash
pacman -S networkmanager
systemctl enable NetworkManager
```

## 13. Users and passwords
Set the root password: 
```bash
passwd
```
Add user and grant sudo privileges: 
```bash
useradd -m -G audio,video,wheel -s /bin/bash <имя пользователя>
* Ключ -m создает пользователю домашний каталог,-G добавляет пользователя в группы, -s устанавливает shell
``` # create a new user
passwd username # set created user password
```
Так как новый пользователь находится в группе wheel, он может пользоваться командой sudo. Нужно только не забыть раскомментировать нужную строку в файле sudoers:
Check privileges:
```bash
sudo -lU username
```

## 14. Grub
i use only one os `os-prober` me don`t need
and `efibootmgr` because `bios` 
```bash
pacman -S grub 
```
Install grub to the disk(not just a partition or path to a directory):
```bash
grub-install --target=i386-pc /dev/sda
```
Generate the grub [`config file`](https://wiki.archlinux.org/title/GRUB#Configuration) this will automatically detect the Arch linux installation:
```bash
grub-mkconfig -o /boot/grub/grub.cfg
```

## 15. Finish
```bash
exit # exit chroot
unmount -R /mnt
reboot
```