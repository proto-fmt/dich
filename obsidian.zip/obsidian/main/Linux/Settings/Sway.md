## Install

```bash
sudo pacman -S sway waybar otf-font-awesome  wofi wl-clipboard alacritty xorg-xwayland qt5-wayland glfw-wayland firefox
```
waybar need otf-font-awesome
# xdg-desktop-portal-wlr

## Fonts 
On Linux-based operating systems, fonts are managed the `fontconfig` library.  
The directories where the fonts should be installed are declared in the `/etc/fonts/font.conf`(don`t edit this file).  
Custom settings should be put in the `/etc/fonts/local.conf` file, which should be created, if it doesn’t exist.

`fc-list` - get the list of the current available fonts on our system
`fc-cache` - re-scanned directories where fonts are stored, and re-created the font cache 

```bash
pacman -S noto-fonts ttf-opensans ttf-dejavu ttf-hack
# ttf-hack - for sway and alacritty
```
Use `pango-list` for choose font in `sway` config file.

commandzsh
## xplr


otham",
colorscheme

## Alacritty 
```bash
mkdir ~/.config/alacritty && touch ~/.config/alacritty/alacritty.toml
```

### Waybar
```bash
mkdir ~/.config/waybar
cp /etc/xdg/waybar/* ~/.config/waybar/
```

Install `paru`:
```bash
git clone https://aur.archlinux.org/paru.git
cd paru
makepkg -si
``` 

Install console display manager [`ly`](https://archlinux.org/packages/extra/x86_64/ly/)
regreet 
```bash
paru -S ly-git
sudo systemctl enable ly.service
```

Create `~/.config/sway/` 
```bash
mkdir -p ~/.config/sway
cp /etc/sway/config ~/.config/sway
```






## Install and setiings `micro`
`wl-clipboard` - command-line copy/paste utilities for Wayland. Without `wl-clipboard` installed, `micro` will use an internal clipboard for copy and paste, but it won't be accessible to external applications. 
```bash
sudo pacman -S micro wl-clipboard
```

`~/.config/micro/settings.json` 
```bash
{
    "backup": false,
    "colorscheme": "darcula",
    "eofnewline": false,
    "rmtrailingws": true,
    "savehistory": false
}
```

`~/.config/micro/bindings.json`
`Ctrl+C`,`Ctrl+V`,`Ctrl+Z` and more is default set. If want schange,  edit `~/.config/micro/bindings.json`. For help in 
```bash
{

}
```